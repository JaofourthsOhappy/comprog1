The OO_Blackjack.py start by 
give you and computer 2 cards, 
but you can't see his first card
until game end. When your hand values
are equal or more than 16 the program will ask you to draw more. If you want to draw type "yes" or "no" to reject.
Then, computer will draw more if his hand values are less than you.Finally, game will calculate values shows the winner and computer's hand